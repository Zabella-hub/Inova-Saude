import sqlite3

conn = sqlite3.connect('custos.db')

cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS custos (
    categoria TEXT,
    valor REAL
)
''')

custos = [
    ('Custo Geral', 10000.0),
    ('Custo dos Medicamentos', 5000.0),
    ('Custo Folha de Pagamento', 7000.0)
]

cursor.executemany('''
INSERT INTO custos (categoria, valor)
VALUES (?, ?)
''', custos)

conn.commit()

cursor.execute('SELECT * FROM custos')
rows = cursor.fetchall()

print("Tabela de Custos:")
for row in rows:
    print(f'{row[0]}: R${row[1]:.2f}')

conn.close()
