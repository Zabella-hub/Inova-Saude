import sqlite3

conn = sqlite3.connect('custos.db')
cursor = conn.cursor()

cursor.execute('SELECT * FROM custos')
rows = cursor.fetchall()

with open('custos.txt', 'w') as file:
    file.write('Categoria\tValor\n')  # Cabeçalhos
    for row in rows:
        file.write(f'{row[0]}\tR${row[1]:.2f}\n')

print("Dados exportados para custos.txt com sucesso!")

conn.close()